package classes;

public class Conferencia extends Veiculo{
    public Conferencia(String sigla, String nome, char tipo, double fatorImpacto){
        super(sigla, nome, tipo, fatorImpacto);
    }
}
