package exceptions;

public class InconsistenciaException extends Exception{
    public InconsistenciaException(String message){
        super(message);
    }
}
